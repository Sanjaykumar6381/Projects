# Modern Login Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/zbcfqrkz-the-selector/pen/ExzwNMj](https://codepen.io/zbcfqrkz-the-selector/pen/ExzwNMj).

This login form is based on Harvani Anjali's design found at:
https://www.uplabs.com/posts/login-screen-designs-icons